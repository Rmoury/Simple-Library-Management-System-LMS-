package edu.qsp.lms.veiw;

import java.util.Scanner;

import edu.qsp.lms.controller.Controller;
import edu.qsp.lms.model.*;

public class View {
	static Scanner myInput = new Scanner(System.in);
	static Library library = new Library();
	static Controller controller = new Controller();
	
	static {
		
		//to perform startup Instruction
		System.out.println("welcome");
		
		System.out.println("enter library name");
		String libraryName = myInput.nextLine();
		library.setLibraryName(libraryName);
		
		System.out.println("enter library Addresss");
		String libraryAddress = myInput.nextLine();
		library.setLibraryAddress(libraryAddress);
		
		System.out.println("enter library pinCode");
		int libraryPincode = myInput.nextInt();
		library.setPinCode(libraryPincode);
	}
	
	public static void main (String[] args) {
		do {
			System.out.println("select operation to perform");
			System.out.println("1.Add Book \n2.Remove Books\n3.Update Books\n4. get Book By name0\n5");
			
			System.out.println("enter a numebr of your choise");
			
			
			int userChoice = myInput.nextInt();
			myInput.nextLine();
			
			switch(userChoice) {
			case 0:
				myInput.close();
				System.out.println("exit");
				System.exit(0);
				break;
			case 1 :
				Book book1 = new Book();
				
				System.out.println("enter book name");
				book1.setBookName(myInput.nextLine());
				
				System.out.println("enter book Auther name");
				book1.setAutherName(myInput.nextLine());
				
				System.out.println("enter book price");
				book1.setPrice(myInput.nextDouble());
				myInput.nextLine();
				
				System.out.println("enter book publication name");
				book1.setPublication(myInput.nextLine());
				
				controller.addBook(book1);
				break;
			case 2:
				System.out.println("enter book to ber removed ");
				String bookToBeremoved = myInput.nextLine();
				boolean flag = controller.removeBook(bookToBeremoved);
				if(flag) {
					System.out.println("book removed");
				}
				else {
					System.out.println("book not exist");
				}
				break;
			case 3 :
				Book book3 = new Book();
				System.out.println("enter book name to update");
				String bookToBeUpdated = myInput.nextLine();
				book3.setBookName(bookToBeUpdated);
				
				System.out.println("enter price to be updated");
				double newPrice = myInput.nextDouble();
				book3.setPrice(newPrice);
				
				if(controller.updateBookPriceByBookName(book3))
					System.out.println("boook price updated");
				else
					System.out.println("book not exist");
				break;
			case 4:
				System.out.println("enter book name to update");
				String bookToGet = myInput.nextLine();
				
				Book book = controller.searchBooks(bookToGet);
				if(book!=null)
					System.out.println(book.toString());
				else
					System.out.println("book not exist");
				break;
			case 5 :
				System.out.println(controller.getAllBooks());
				break;
			default:
					break;
				
			}
		}while(true);
	}

 }
